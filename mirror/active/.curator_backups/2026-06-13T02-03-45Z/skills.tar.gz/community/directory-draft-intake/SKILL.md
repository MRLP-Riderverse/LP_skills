---
name: directory-draft-intake
description: Hyper-low-friction workflow for staging Acadie.sol directory inbox entries from live conversation or public research. Inbox layer is Name + Notes first; cleanup and normalization happen later.
version: 1.2.0
category: community
metadata:
  hermes:
    tags: [directory, intake, inbox, drafting, community, capture, scraping, raw-capture, low-friction]
    related_skills: [hermes-agent, software-development-workflow]
---

# Directory Draft Intake

Use this skill when the user wants to add, draft, or stage an entry for the `acadie_sol_directory` inbox.

This is the **hyper-low-friction inbox layer**.
At this stage, the draft should feel closer to **Name + Notes** than to a form.

## Trigger phrases

Treat the following as intake commands, not open-ended discussion:

- "add this to the acadie directory inbox"
- "add this to the acadian directory inbox"
- "draft this as a manual entry"
- "capture this in person"
- "put this in the inbox"
- any live owner / on-foot intel the user wants preserved as a directory draft

## Intent

The goal is to preserve raw local intelligence with minimal friction and minimal meaning loss.

Core goals:
- capture the entry even when the information is incomplete
- preserve the user’s live wording when it carries local meaning
- avoid making the intake feel like a form
- prevent over-sorting too early
- keep the inbox easy to read later during cleanup
- move structure and parsing pressure to the later normalization pass

## Default attribution rules

Use these defaults unless the user explicitly overrides them:

- **Submitted by:** `Acadie.sol`
- If the user explicitly says they are there, witnessed it, or captured it live, preserve that in notes or admin notes.
- Do **not** force `Source: In person` when the user did not actually say it.
- Public URLs are welcome when present, but never required for inbox capture.

## Inbox principle

**The inbox is not the final schema.**

It is a staging layer.
The point is to preserve raw intelligence in a way that is easy to create now and easy to revisit later.

At this stage, the assistant should optimize for:
- fidelity
- speed
- recoverability
- readability during cleanup

## Minimum viable intake shape

Only one field is truly mandatory:

- **Name**

Everything else can be captured as:

- **Notes**
- If the user provides a city / area / neighborhood, keep it visibly in the draft header or early notes so it is not easy to miss in the echoed confirmation.

That means the entry can succeed even if the user gives:
- rough location
- address
- public details
- features
- vibe
- hours caveat
- verification hints
- source context
- owner observations
- mixed notes

All of that can stay in notes at draft stage.

## Preferred inbox draft shape

Use this shape by default for live intake:

```md
# Draft: <Name>

## Notes
<raw notes preserved in plain language>

## Admin notes
- Submitted by : Acadie.sol
- ...
```

If there are no true admin notes beyond attribution, keep only:

```md
## Admin notes
- Submitted by : Acadie.sol
```

## Field behavior

### Name
- Required if the user is asking to draft a place.
- Preserve the best available business/place name.
- If the user later corrects the name, patch the title directly.

### Notes
This is the main inbox capture bucket.

Use it for:
- what the place is
- location / address / wayfinding
- public-facing features
- useful local recommendations
- hours caveats
- vibe / felt impression
- witnessed details
- mixed public/admin-ish fragments when early sorting would cause loss

Examples of details that can stay in notes:
- `local foods restaurant at 1395 Miramichi Ave`
- `amazing Donair and Steak Subs`
- `great Poutine`
- `daily open hours are short`
- `worth trying if you can catch them during open hours`
- `nice`
- `near Daly Point`
- `up Bridge St`

At inbox stage, preserving the phrasing is usually better than prematurely converting it into categories.
Light punctuation or capitalization cleanup is fine if it improves readability, but do not rewrite in a way that changes tone, confidence, or meaning.

### Admin notes
Use for:
- attribution
- explicit verification reminders
- clearly internal follow-up
- known uncertainty the user would want remembered during cleanup

Always keep:
- `Submitted by : Acadie.sol`

Keep admin notes short.
Do not dump half the capture into admin notes just because it is imperfect.

## Multi-location handling

When the user gives a batch of businesses or a chain with multiple local branches:

- write one draft per physical location
- disambiguate the title with the street address, neighborhood, or branch name when needed
- do not collapse distinct branches into one card just because the brand is shared
- if there are two known locations and the user mentions both, stage both drafts immediately
- preserve any unresolved location ambiguity in `## Notes` instead of forcing a guess

This is especially useful for restaurant chains, campuses, libraries, and waterfront clusters where multiple branches or sub-locations are part of the same conversation.

## Reliability rules

- Never fail the draft because phone, hours, email, address, category, or source label are missing.
- Never force a URL.
- Never force an address into a dedicated field at inbox stage.
- Never force wayfinding into its own field at inbox stage.
- Never pad the draft with placeholders like `not provided`.
- Never over-summarize if that would lose the raw felt meaning of the user’s note.
- If a detail is uncertain but useful, preserve it in notes or brief admin notes instead of dropping it.
- Prefer readability over pseudo-structure.
- Before writing a new draft, check `inbox/` for an existing same-name or obvious twin entry.
- If a likely duplicate already exists, do **not** silently overwrite or create a second draft.
- In that case, report back exactly in this shape: `I believe you already have an entry for this: <path>` and wait for the user to decide what to do next.

## Manual capture workflow

1. Read the user’s instruction as an intake command.
2. Extract the name.
3. Check `inbox/` for an existing same-name or obvious twin entry before writing.
4. If a likely duplicate exists, stop and report: `I believe you already have an entry for this: <path>`.
5. If no likely duplicate exists, put everything else into `## Notes` with minimal cleanup.
6. Preserve meaningful wording, including rough location, praise, caveats, and local feel.
7. Add `Submitted by : Acadie.sol` in admin notes unless told otherwise.
8. Only add extra admin notes when there is a real follow-up or verification point worth carrying.
9. Write the draft into `inbox/` without waiting for more fields.

## Batch release workflow

Use this when the user follows draft capture with commands like `commit`, `push`, or `export to site`.

1. Commit the new inbox drafts in `acadie_sol_directory`.
2. Push `acadie_sol_directory` to `origin/main`.
3. Run `scripts/export_to_site.py` from `acadie_sol_directory`.
4. Commit the updated `acadie_sol/assets/directory-data.json` in `acadie_sol`.
5. Push `acadie_sol` to `origin/main`.

Do not stop after the draft exists if the user asked for release actions too.

## Public research shortcuts

When the user asks for a batch of places and the web data is fragmented:
- prefer official municipal/service pages or official brand/location pages first
- use result titles/snippets from search as backup for branch names, addresses, and hours
- keep one draft per physical location
- if a chain has multiple branches in the same region, disambiguate the title with the street address or branch label
- keep partial uncertainty in `## Notes` rather than blocking the draft
- when a claim is useful but not explicitly confirmed by the source (for example: fire tolerance, access rules, seasonal operations), keep it out of public claims and mark it as unverified in `## Admin notes`
- capture operational details from authoritative city pages when present (hours, parking, lifeguards, designated zones, access notes, pets, camping, rentals, cleanup schedules)

## Later normalization

A later pass can parse the notes into cleaner structure such as:
- category
- area
- address
- wayfinding
- hours
- public notes
- public source
- admin follow-up
- relationship notes (`related_places`, `nearby_places`, `shared_events`)

That parsing is intentionally postponed.

When a useful corridor or cluster shows up, leave a lightweight reminder in the clean-entry area so future work can find it quickly (for example a small graph notes page or equivalent relation note), instead of burying the idea only in inbox drafts.

## Why this shape is preferred

This format is better for live work because:
- it lowers expectations during capture
- it preserves meaning instead of forcing early sorting
- it makes drafts faster to create in person or on the move
- it makes later cleanup easier because the whole raw thought is still visible in one place

## Loading tool / preflight wrapper

In Telegram, the session preflight command is `/draftload`.

Its role should be:
- act like an "I’m about to input some draft entries" mode
- tell the agent that only **Name** is mandatory
- tell the agent that everything else can remain in **Notes**
- reduce live expectations
- avoid turning capture into a mini-form

The loader is a readiness layer, not the real intake requirement.

## Session lessons captured

- `Frost Bite` proved that local visitor-helpful notes matter.
- `Theriault’s Grocers` proved that rough wayfinding and observed description can be enough for a valuable draft.
- `Bowlarama Bathurst Bowling & Arcade` showed that features + vibe survive better when not over-sorted.
- `Eastside Deli` showed that address + praise + hours caveat are easier to preserve as notes than as forced mini-fields.
- The inbox stage should optimize for preservation first, parsing second.

## Success criteria

A good result is:
- the user can draft an entry quickly during live work
- only the name is required
- the notes preserve the raw local meaning
- the draft is easy to read later during cleanup
- missing structure does not block capture
- later normalization still has enough material to work from

## Capture confirmation

When the user asks to confirm a newly captured draft, keep the reply short but include the normalized title plus any explicit top-level location field that was captured. Do not omit a location field from the confirmation if it is present in the draft.

See `references/capture-confirmation-note.md` for the session-specific reminder.

## Linked support files

- `references/draft-template.md` — canonical Name + Notes inbox draft skeleton
- `references/session-notes.md` — compact lessons and pitfalls from batch intake, chain branches, and waterfront cluster handling
- `references/batch-location-research-notes.md` — workflow notes for batch franchise/location research and branch disambiguation
- `references/duplicate-guard-and-script.md` — duplicate-warning rule, exact fallback wording, and deterministic helper usage
- `references/public-source-verification.md` — source-order and verification notes for enriching drafts from official city/service pages
- `references/public-source-verification.md` — source-order and verification notes for enriching drafts from official city/service pages
- `references/site-sync-workflow.md` — commit / push / export / publish sequence for the two-repo setup
- `scripts/draft_intake.py` — deterministic renderer for later structured normalization or conversion
