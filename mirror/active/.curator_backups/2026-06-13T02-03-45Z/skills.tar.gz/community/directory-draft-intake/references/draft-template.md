# Directory Draft Template

```md
# Draft: <Name>

## Notes
<raw notes preserved in plain language>

## Admin notes
- Submitted by : Acadie.sol
- ...
```

## Field policy

- This is an inbox-stage staging template, not the final normalized directory schema.
- Only the name is mandatory.
- Everything else can stay in `## Notes`.
- Preserve raw local wording instead of prematurely sorting into fields.
- Do not pad with placeholders.
- Do not force address, wayfinding, hours, or source into dedicated fields at draft stage.
- If the user explicitly says they witnessed it or are there in person, preserve that in notes or admin notes.
- Keep `Submitted by : Acadie.sol` as the default attribution unless overridden.
- Use extra admin notes only for real verification or follow-up needs.
- Before writing, check `inbox/` for a same-name or obvious twin entry.
- If a likely duplicate already exists, stop and report exactly: `I believe you already have an entry for this: <path>`.
- A later pass may normalize the note into public data, wayfinding, source, and clean entry structure.
