# Hermes Skill Backup Mirror Sync

Use this when maintaining a sibling repo that mirrors *agent-made* Hermes skills from a live `~/.hermes/skills` tree.

## Workflow

1. Identify the live source root and the backup repo root.
2. Filter to agent-made skills only; do not mix in bundled/base Hermes skills.
3. Match skills by a normalized leaf name so `directory-card-lookup`, `directory_card_lookup`, and path-variant layouts resolve to the same skill.
4. Compare the full skill directory, not just `SKILL.md`.
5. Use content hashes or `diff -qr` to catch drift in `references/`, `templates/`, `scripts/`, and generated helper files.
6. If one skill needs a shared wrapper script or similar runtime helper, verify that file's checksum too.
7. Commit the mirror refresh as a single chore, then push.
8. Re-run a read-only verification after push and expect a clean working tree.

## Pitfalls

- `SKILL.md` parity alone is insufficient; support files can drift independently.
- Do not assume hyphenated and underscored skill names are distinct.
- Treat runtime cache files and generated artifacts carefully; mirror only what the backup policy intends to preserve.
- If the backup repo is used as a restore point, keep the commit atomic so future recovery is unambiguous.
